let entries = []
let notes   = ""
let activeTab = "snippets"

// ════════════════════════════════════════════
//  MARKDOWN RENDERER
//  Supports: h1-h6, bold, italic, bold+italic,
//  strikethrough, inline code, code blocks,
//  blockquotes, ordered + unordered lists,
//  horizontal rules, line breaks, links
// ════════════════════════════════════════════
function renderMarkdown(raw) {
  const lines  = raw.split("\n")
  const output = []
  let i = 0

  while (i < lines.length) {
    const line = lines[i]

    // ── Fenced code block ```
    if (line.trimStart().startsWith("```")) {
      const lang = line.trim().slice(3).trim()
      const codeLines = []
      i++
      while (i < lines.length && !lines[i].trimStart().startsWith("```")) {
        codeLines.push(escHtml(lines[i]))
        i++
      }
      output.push(`<pre><code${lang ? ` class="lang-${escHtml(lang)}"` : ""}>${codeLines.join("\n")}</code></pre>`)
      i++
      continue
    }

    // ── Horizontal rule --- / *** / ___
    if (/^(\*{3,}|-{3,}|_{3,})\s*$/.test(line.trim())) {
      output.push("<hr>")
      i++
      continue
    }

    // ── Heading
    const hMatch = line.match(/^(#{1,6})\s+(.+)$/)
    if (hMatch) {
      const level = hMatch[1].length
      output.push(`<h${level}>${inlineMarkdown(hMatch[2])}</h${level}>`)
      i++
      continue
    }

    // ── Blockquote
    if (line.startsWith(">")) {
      const bqLines = []
      while (i < lines.length && lines[i].startsWith(">")) {
        bqLines.push(lines[i].replace(/^>\s?/, ""))
        i++
      }
      output.push(`<blockquote>${renderMarkdown(bqLines.join("\n"))}</blockquote>`)
      continue
    }

    // ── Unordered list  (- / * / +)
    if (/^(\s*)([-*+])\s+/.test(line)) {
      const listItems = []
      while (i < lines.length && /^(\s*)([-*+])\s+/.test(lines[i])) {
        const text = lines[i].replace(/^\s*[-*+]\s+/, "")
        listItems.push(`<li>${inlineMarkdown(text)}</li>`)
        i++
      }
      output.push(`<ul>${listItems.join("")}</ul>`)
      continue
    }

    // ── Ordered list  (1. / 2. …)
    if (/^\d+\.\s+/.test(line)) {
      const listItems = []
      while (i < lines.length && /^\d+\.\s+/.test(lines[i])) {
        const text = lines[i].replace(/^\d+\.\s+/, "")
        listItems.push(`<li>${inlineMarkdown(text)}</li>`)
        i++
      }
      output.push(`<ol>${listItems.join("")}</ol>`)
      continue
    }

    // ── Blank line → paragraph break
    if (line.trim() === "") {
      output.push("<br>")
      i++
      continue
    }

    // ── Regular paragraph line
    output.push(`<p>${inlineMarkdown(line)}</p>`)
    i++
  }

  return output.join("")
}

// Inline formatting: bold+italic, bold, italic, strike, code, links
function inlineMarkdown(text) {
  // Protect inline code first (replace with placeholders)
  const codeChunks = []
  text = text.replace(/`([^`]+)`/g, (_, code) => {
    codeChunks.push(`<code>${escHtml(code)}</code>`)
    return `\x00${codeChunks.length - 1}\x00`
  })

  text = escHtml(text)

  // Bold + italic  ***text***  or  ___text___
  text = text.replace(/\*\*\*(.+?)\*\*\*/g, "<strong><em>$1</em></strong>")
  text = text.replace(/___(.+?)___/g,        "<strong><em>$1</em></strong>")

  // Bold  **text**  or  __text__
  text = text.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
  text = text.replace(/__(.+?)__/g,     "<strong>$1</strong>")

  // Italic  *text*  or  _text_
  text = text.replace(/\*([^*\n]+?)\*/g, "<em>$1</em>")
  text = text.replace(/_([^_\n]+?)_/g,   "<em>$1</em>")

  // Strikethrough  ~~text~~
  text = text.replace(/~~(.+?)~~/g, "<del>$1</del>")

  // Links  [label](url)
  text = text.replace(/\[([^\]]+)\]\(([^)]+)\)/g,
    '<a href="$2" target="_blank" rel="noopener">$1</a>')

  // Restore inline code placeholders
  text = text.replace(/\x00(\d+)\x00/g, (_, idx) => codeChunks[Number(idx)])

  return text
}

function escHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
}

// ════════════════════════════════════════════
//  STORAGE
// ════════════════════════════════════════════
function load() {
  chrome.storage.local.get(["entries", "notes"], (data) => {
    entries = data.entries || []
    notes   = data.notes   || ""
    document.getElementById("notes").value = notes
    render()
  })
}

// ════════════════════════════════════════════
//  HELPERS
// ════════════════════════════════════════════
function timeAgo(iso) {
  const diff = Date.now() - new Date(iso).getTime()
  const s = Math.floor(diff / 1000)
  if (s < 60)  return "just now"
  const m = Math.floor(s / 60)
  if (m < 60)  return `${m}m ago`
  const h = Math.floor(m / 60)
  if (h < 24)  return `${h}h ago`
  return new Date(iso).toLocaleDateString("en-US", { month: "short", day: "numeric" })
}

function hostname(url) {
  try { return new URL(url).hostname.replace(/^www\./, "") }
  catch { return "" }
}

function faviconUrl(url) {
  try {
    return `https://www.google.com/s2/favicons?sz=16&domain_url=${encodeURIComponent(new URL(url).origin)}`
  } catch { return null }
}

// ════════════════════════════════════════════
//  RENDER SNIPPETS
// ════════════════════════════════════════════
function render() {
  const wrap  = document.getElementById("entries-wrap")
  const count = document.getElementById("count")

  count.textContent = `${entries.length} capture${entries.length !== 1 ? "s" : ""}`

  if (entries.length === 0) {
    wrap.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
            <path d="M12 5v14M5 12h14" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/>
          </svg>
        </div>
        <div class="empty-title">No captures yet</div>
        <div class="empty-body">
          Select text on any page and <strong>right-click → Add to Quick Docs</strong>.
        </div>
      </div>
    `
    return
  }

  const listHtml = entries.map(e => {
    const fav  = faviconUrl(e.url)
    const host = hostname(e.url)
    const favEl = fav
      ? `<img class="entry-favicon" src="${escHtml(fav)}" alt="" onerror="this.style.display='none'">`
      : `<div class="entry-favicon-placeholder">⬡</div>`

    return `
      <div class="entry" data-id="${e.id}">
        <div class="entry-header">
          <div class="entry-source-wrap">
            ${favEl}
            <a class="entry-source" href="${escHtml(e.url || "")}"
               title="${escHtml(e.url || "")}" target="_blank" rel="noopener">
              ${escHtml(e.title || host || "Unknown source")}
            </a>
          </div>
          <div class="entry-time">${timeAgo(e.timestamp)}</div>
        </div>
        <div class="entry-body md-content">${renderMarkdown(e.text)}</div>
        <div class="entry-actions">
          <button class="action-link copy-btn" data-id="${e.id}">Copy</button>
          <button class="action-link del del-btn" data-id="${e.id}">Delete</button>
        </div>
      </div>
    `
  }).join("")

  wrap.innerHTML = `<div class="entries-list">${listHtml}</div>`

  wrap.querySelectorAll(".copy-btn").forEach(btn => {
    btn.onclick = () => {
      const e = entries.find(x => x.id === Number(btn.dataset.id))
      if (!e) return
      navigator.clipboard.writeText(e.text)
      btn.textContent = "Copied!"
      setTimeout(() => { btn.textContent = "Copy" }, 1500)
    }
  })

  wrap.querySelectorAll(".del-btn").forEach(btn => {
    btn.onclick = () => deleteEntry(Number(btn.dataset.id))
  })
}

// ════════════════════════════════════════════
//  TAB SWITCHING
// ════════════════════════════════════════════
document.getElementById("menu-snippets").onclick = () => switchTab("snippets")
document.getElementById("menu-notes").onclick    = () => switchTab("notes")
document.getElementById("menu-docs").onclick     = () => switchTab("docs")

function switchTab(tab) {
  activeTab = tab
  document.getElementById("menu-snippets").classList.toggle("active", tab === "snippets")
  document.getElementById("menu-notes").classList.toggle("active", tab === "notes")
  document.getElementById("menu-docs").classList.toggle("active", tab === "docs")
  document.getElementById("page-snippets").classList.toggle("hidden", tab !== "snippets")
  document.getElementById("page-notes").classList.toggle("hidden", tab !== "notes")
  document.getElementById("page-docs").classList.toggle("hidden", tab !== "docs")
  // Let iframe scroll itself; disable canvas scroll when on docs
  document.querySelector(".canvas").style.overflow = tab === "docs" ? "hidden" : "auto"
}

// ════════════════════════════════════════════
//  NOTES: EDIT / PREVIEW TOGGLE
// ════════════════════════════════════════════
let notesMode = "edit"

document.getElementById("notes-edit-btn").onclick = () => setNotesMode("edit")
document.getElementById("notes-preview-btn").onclick = () => setNotesMode("preview")

function setNotesMode(mode) {
  notesMode = mode
  const isEdit = mode === "edit"
  document.getElementById("notes").classList.toggle("hidden", !isEdit)
  document.getElementById("notes-preview").classList.toggle("hidden", isEdit)
  document.getElementById("notes-edit-btn").classList.toggle("active", isEdit)
  document.getElementById("notes-preview-btn").classList.toggle("active", !isEdit)

  if (!isEdit) {
    document.getElementById("notes-preview").innerHTML =
      notes.trim() ? renderMarkdown(notes) : `<p class="preview-empty">Nothing to preview yet.</p>`
  }
}

document.getElementById("notes").oninput = (e) => {
  notes = e.target.value
  chrome.storage.local.set({ notes })
}

// ════════════════════════════════════════════
//  ACTIONS
// ════════════════════════════════════════════
function deleteEntry(id) {
  entries = entries.filter(e => e.id !== id)
  chrome.storage.local.set({ entries })
  render()
}

document.getElementById("clear").onclick = () => {
  if (entries.length === 0) return
  if (!confirm(`Delete all ${entries.length} capture(s)?`)) return
  entries = []
  chrome.storage.local.set({ entries })
  render()
  setStatus("All captures cleared.", "success")
}

document.getElementById("copy-all").onclick = () => {
  if (entries.length === 0) return setStatus("Nothing to copy.", "error")
  const text = entries.map((e, i) =>
    `[${i + 1}] ${e.title || hostname(e.url)}\n${e.text}`
  ).join("\n\n---\n\n")
  navigator.clipboard.writeText(text)
  setStatus("All snippets copied to clipboard.", "success")
}

// ════════════════════════════════════════════
//  FILE MENU — DROPDOWN TOGGLE
// ════════════════════════════════════════════
const fileBtn      = document.getElementById("file-btn")
const fileDropdown = document.getElementById("file-dropdown")

fileBtn.onclick = (e) => {
  e.stopPropagation()
  fileDropdown.classList.toggle("hidden")
}

// Close dropdown when clicking anywhere else
document.addEventListener("click", () => {
  fileDropdown.classList.add("hidden")
})

fileDropdown.addEventListener("click", (e) => e.stopPropagation())

// ════════════════════════════════════════════
//  EXPORT MODAL
// ════════════════════════════════════════════
const exportOverlay = document.getElementById("export-overlay")
const chkSnippets   = document.getElementById("chk-snippets")
const chkNotes      = document.getElementById("chk-notes")

document.getElementById("export-btn").onclick = () => {
  fileDropdown.classList.add("hidden")

  if (entries.length === 0 && !notes.trim()) {
    return setStatus("Nothing to export yet.", "error")
  }

  // Update counts
  document.getElementById("export-snippet-count").textContent =
    entries.length === 0 ? "empty" : `${entries.length} snippet${entries.length !== 1 ? "s" : ""}`
  document.getElementById("export-notes-count").textContent =
    notes.trim() ? `${notes.trim().split("\n").length} line${notes.trim().split("\n").length !== 1 ? "s" : ""}` : "empty"

  // Pre-check only what has content
  chkSnippets.checked = entries.length > 0
  chkNotes.checked    = notes.trim().length > 0

  // Disable empty options
  chkSnippets.disabled = entries.length === 0
  chkNotes.disabled    = !notes.trim()
  document.getElementById("opt-snippets").style.opacity = entries.length === 0 ? "0.4" : "1"
  document.getElementById("opt-notes").style.opacity    = !notes.trim() ? "0.4" : "1"

  exportOverlay.classList.remove("hidden")
}

document.getElementById("export-cancel").onclick = () => {
  exportOverlay.classList.add("hidden")
}

exportOverlay.onclick = (e) => {
  if (e.target === exportOverlay) exportOverlay.classList.add("hidden")
}

document.getElementById("export-confirm").onclick = () => {
  const wantSnippets = chkSnippets.checked && entries.length > 0
  const wantNotes    = chkNotes.checked && notes.trim()

  if (!wantSnippets && !wantNotes) {
    return setStatus("Select at least one option.", "error")
  }

  const parts = []

  if (wantNotes) {
    parts.push(`NOTES\n${"─".repeat(36)}\n${notes.trim()}\n`)
  }

  if (wantSnippets) {
    if (parts.length) parts.push("\n\n")
    parts.push(`CAPTURED SNIPPETS  (${entries.length})\n${"─".repeat(36)}\n`)
    entries.forEach((e, i) => {
      const when = new Date(e.timestamp).toLocaleString()
      const src  = e.title || hostname(e.url) || "Unknown source"
      parts.push(`\n[${i + 1}]  ${src}\n${when}${e.url ? `\n${e.url}` : ""}\n\n${e.text}\n`)
    })
  }

  const blob = new Blob([parts.join("")], { type: "text/plain;charset=utf-8" })
  const url  = URL.createObjectURL(blob)
  const a    = document.createElement("a")
  a.href     = url
  a.download = `quick-docs-${new Date().toISOString().slice(0,10)}.txt`
  a.click()
  URL.revokeObjectURL(url)

  exportOverlay.classList.add("hidden")
  setStatus("✓ Exported successfully.", "success")
}

// ════════════════════════════════════════════
//  IMPORT — read .txt file
// ════════════════════════════════════════════
document.getElementById("import-btn").onclick = () => {
  fileDropdown.classList.add("hidden")
  document.getElementById("file-input").click()
}

document.getElementById("file-input").onchange = (e) => {
  const file = e.target.files[0]
  if (!file) return

  // Reset so the same file can be re-imported
  e.target.value = ""

  const reader = new FileReader()
  reader.onload = (ev) => {
    const text = ev.target.result.trim()
    if (!text) return setStatus("File is empty.", "error")

    // Add as a new snippet entry
    const newEntry = {
      id:        Date.now(),
      text,
      url:       "",
      title:     file.name,
      timestamp: new Date().toISOString()
    }
    entries.unshift(newEntry)
    chrome.storage.local.set({ entries })
    render()
    switchTab("snippets")
    setStatus(`✓ Imported "${file.name}"`, "success")
  }
  reader.readAsText(file)
}

// ════════════════════════════════════════════
//  STATUS BAR
// ════════════════════════════════════════════
//  STATUS BAR
// ════════════════════════════════════════════
let statusTimer = null
function setStatus(msg, type = "") {
  const el = document.getElementById("status")
  el.textContent = msg
  el.className   = "statusbar " + type
  clearTimeout(statusTimer)
  if (type) statusTimer = setTimeout(() => {
    el.textContent = ""
    el.className   = "statusbar"
  }, 4000)
}

function setStatusLink(msg, linkText, url) {
  const el = document.getElementById("status")
  el.className = "statusbar success"
  el.innerHTML = ""
  const span = document.createElement("span")
  span.textContent = msg
  const a = document.createElement("a")
  a.textContent = linkText
  a.href = url
  a.target = "_blank"
  a.rel = "noopener"
  a.style.cssText = "color:#1a73e8;font-weight:600;text-decoration:none;margin-left:2px;"
  a.onmouseenter = () => a.style.textDecoration = "underline"
  a.onmouseleave = () => a.style.textDecoration = "none"
  a.onclick = (e) => { e.preventDefault(); chrome.tabs.create({ url }) }
  el.appendChild(span)
  el.appendChild(a)
  clearTimeout(statusTimer)
}

// ════════════════════════════════════════════
//  LIVE SYNC
// ════════════════════════════════════════════
chrome.storage.onChanged.addListener((changes) => {
  if (changes.entries) {
    entries = changes.entries.newValue || []
    if (activeTab === "snippets") render()
    else document.getElementById("count").textContent =
      `${entries.length} capture${entries.length !== 1 ? "s" : ""}`
  }
})

// ── Init ──
switchTab("snippets")
load()