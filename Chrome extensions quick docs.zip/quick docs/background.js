chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {})

// ── Register context menu on install ──
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id:       "capture-to-qdocs",
    title:    "Add to Quick Docs",
    contexts: ["selection"]
  })
})

// ── Context menu click ──
// Browser provides selectionText directly — no scripting injection needed.
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId !== "capture-to-qdocs") return
  const text = info.selectionText?.trim()
  if (!text) return
  saveEntry({ text, url: info.pageUrl, title: tab?.title || "" })
})

// ── Shared save logic ──
function saveEntry({ text, url, title }) {
  chrome.storage.local.get(["entries"], (data) => {
    const entries = data.entries || []
    entries.unshift({
      id:        Date.now(),
      text,
      url:       url || "",
      title:     title || "",
      timestamp: new Date().toISOString()
    })
    chrome.storage.local.set({ entries })
  })
}